Project09 - Hangman Game

By: Vicente Gonzalez
    Isaac Valdez
Your name

Total time to complete assignment was about 4-5 hours.

Tips:
Making use of the programing language's draw box's function was very helpful as opposed to drawing black boxes as the user guessed their answers. This helped reduce the amount of work done when writing the program. Most of the information on how to code this was found in chapter 09 of the Elements of Computing book.



Project 09 will be the game Hangman executed in JACK a simple programming language used in the Nand2Tetris course and part of the CSCI course at mines: Elements of Computing. 

	Main.jack
		-Used to run the bulk of the program, calls the hangman classes
		
	Hangman.jack 
		- Default game setup
		- holds the hung man
		- Implements the game functionality
		- Calls all the Drawing functions for the Screen.
